/**
 * @author Luuxis
 * @license CC-BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0
 */

import { skin2D } from './Skin/skin2D.js'

export {
    skin2D as skin2D
}